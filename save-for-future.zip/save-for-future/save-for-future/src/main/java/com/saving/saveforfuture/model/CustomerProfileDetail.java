package com.saving.saveforfuture.model;

import lombok.Data;
import lombok.experimental.Accessors;
import java.time.LocalDate;

@Data
@Accessors(chain = true)
public class CustomerProfileDetail {
    private String customerId;
    private String email;
    private LocalDate dob;
    private int age;
    private int memberno;
    private int monthlyIncome;
    private int monthlyExpense;
    private int tax;
    private int ageOfRetirement;
    private int password;
    private String savingId;
    private String gender;
}
